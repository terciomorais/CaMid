package br.ufpe.cin.in1118.application.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import br.ufpe.cin.in1118.distribution.server.NamingInvoker;

public class NamingBroker {

	public static void main(String[] args) {
		NamingInvoker namingInvoker = new NamingInvoker();
		ServerSocket server;
		
		try {
			server = new ServerSocket(Integer.parseInt(args[0]));
			
			while(true){
				Socket conn = server.accept();
				
				DataInputStream dis = new DataInputStream(conn.getInputStream());
				DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
				
				byte[] incomingMessage = new byte[dis.readInt()];
				dis.read(incomingMessage);
				namingInvoker.setIncomingMessage(incomingMessage);
				byte[] outcomingMessage = namingInvoker.invoke();
				
				int msgSize = outcomingMessage.length;
				dos.writeInt(msgSize);
				dos.write(outcomingMessage);
				dos.flush();
				
				conn.close();
				dis.close();
				dos.close();
			}
			
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
