package br.ufpe.cin.in1118.application.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Set;

import br.ufpe.cin.in1118.distribution.stub.CalculatorStub;
import br.ufpe.cin.in1118.distribution.stub.NamingStub;
import br.ufpe.cin.in1118.infrastructure.server.ServerRequestHandler;
import br.ufpe.cin.in1118.services.commons.naming.LocalServiceRegistry;

public class Broker {
	
	private ServerSocket 			server		= null;
	private ServerRequestHandler	srh			= ServerRequestHandler.getInstance();
//	private LocalServiceRegistry	registry	= null;
	private int						port		= 1313;
	
	public void start (int portNumber) {
	//	this.registry = LocalServiceRegistry.createDefault();
		this.port = portNumber;
		
		//Preparing to bind the remote object
		NamingStub naming = new NamingStub("localhost", 1111);
		
		CalculatorStub calculatorStub = new CalculatorStub();
		calculatorStub.setHost("localhost");
		calculatorStub.setPort(this.port);
		calculatorStub.setObjectId(1);
		
		try {
			//binding object
			naming.bind("calculator", calculatorStub);
			
			if(this.server == null)
				this.server = new ServerSocket(this.port);

			while(true)
				srh.receive(this.server.accept());

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			this.endServer();
		}
	}
	
/*	public void bindServices(){
		Set<String> serviceNames = this.registry.getAllServices();
		for(String serviceName : serviceNames){
			
		}
	}*/
	
	public void endServer(){
		if(this.server != null && !this.server.isClosed())
			try {
				this.server.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
