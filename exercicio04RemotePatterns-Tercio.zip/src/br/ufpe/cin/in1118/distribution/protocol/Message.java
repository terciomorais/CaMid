package br.ufpe.cin.in1118.distribution.protocol;

import java.io.Serializable;

public class Message implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private MessageHeader	header;
	private MessageBody		body;
	
	public Message(){
		
	}
	public Message(MessageHeader header, MessageBody body) {
		this.setHeader(header);
		this.setBody(body);
	}
	public MessageHeader getHeader() {
		return header;
	}
	public void setHeader(MessageHeader header) {
		this.header = header;
	}
	public MessageBody getBody() {
		return body;
	}
	public void setBody(MessageBody body) {
		this.body = body;
	}
}
