package br.ufpe.cin.in1118.distribution.protocol;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RequestBody implements Serializable{

	private static final long serialVersionUID = 1L;
	private List<Object> parameters = new ArrayList<Object>();

	public RequestBody(List<Object> parameters) {
		this.setParameters(parameters);
	}

	public List<Object> getParameters() {
		return parameters;
	}

	public void setParameters(List<Object> parameters) {
		this.parameters = parameters;
	}
	
	public Object getParameter(int index){
		return this.parameters.get(index);
	}
	
	public void setParameter(Object param){
		this.parameters.add(param);
	}
}
