	package br.ufpe.cin.in1118.distribution.protocol;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class InvocationDescriptor implements Serializable{

	private static final long serialVersionUID	= 1L;
	private String			hostIP				= "";
	private int				port;
	private int				objectID;
	
	private String			remoteObjName		= null;
	private String 			methodName			= null;
	private List<Object>	parameters			= null;
	private boolean			hasReturn			= true;
	private String 			returnType			= null;
	
	public String getHostIP() {
		return hostIP;
	}
	public void setHostIP(String hostIP) {
		this.hostIP = hostIP;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public int getObjectID() {
		return objectID;
	}
	public void setObjectID(int objectID) {
		this.objectID = objectID;
	}
	public void setParameters(List<Object> parameters) {
		this.parameters = parameters;
	}
	public String getRemoteObjName() {
		return remoteObjName;
	}
	public void setRemoteObjName(String remoteObjName) {
		this.remoteObjName = remoteObjName;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public boolean isHasReturn() {
		return hasReturn;
	}
	public void setHasReturn(boolean hasReturn) {
		this.hasReturn = hasReturn;
	}
	public String getReturnType() {
		return returnType;
	}
	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
	
	public void addParameter (Object param){
		if (this.parameters == null)
			this.parameters = new ArrayList<Object>();
		this.parameters.add(param);
	}
	
	public Object getParameter(int index){
		Object result = null;
		if (this.parameters != null && !this.parameters.isEmpty())
			result = this.parameters.get(index);
		return result;
	}
	
	public List<Object> getParameters(){
		return this.parameters;
	}

}
