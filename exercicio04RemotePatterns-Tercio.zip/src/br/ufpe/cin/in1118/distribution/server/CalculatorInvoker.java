package br.ufpe.cin.in1118.distribution.server;

import java.io.IOException;

import br.ufpe.cin.in1118.distribution.marshaling.Marshaller;
import br.ufpe.cin.in1118.distribution.protocol.Message;
import br.ufpe.cin.in1118.distribution.protocol.MessageBody;
import br.ufpe.cin.in1118.distribution.protocol.MessageHeader;
import br.ufpe.cin.in1118.distribution.protocol.ReplyBody;
import br.ufpe.cin.in1118.distribution.protocol.ReplyDescriptor;
import br.ufpe.cin.in1118.distribution.protocol.ReplyHeader;
import br.ufpe.cin.in1118.distribution.skeleton.Calculator;

public class CalculatorInvoker {
	
	private byte[]			incomingMessage			= null;
	private Message			inUnmarshalledMessage	= null;
	private Message 		outUnmarshalledMessage	= null;
	private byte[]			outMarshalledMessage	= null;
	private ReplyDescriptor	reply 					= new ReplyDescriptor();

	
	public CalculatorInvoker() {}
	
	public CalculatorInvoker(byte[] receivedMessage) {
		this.incomingMessage = receivedMessage;
	}
	
	public byte[] invoke() throws ClassNotFoundException, IOException, InterruptedException {
		Marshaller marshaller = new Marshaller();
		this.inUnmarshalledMessage = marshaller.unmarshall(this.incomingMessage);
		
		switch (this.inUnmarshalledMessage.getBody().getRequestHeader().getOperation()) {

		case "add":
			Float _add_p1 = (Float) this.inUnmarshalledMessage.getBody()
				.getRequestBody().getParameter(0);
			Float _add_p2 = (Float) this.inUnmarshalledMessage.getBody()
				.getRequestBody().getParameter(1);
			reply.setResponse(new Calculator().add(_add_p1, _add_p2));

			this.outUnmarshalledMessage
				= new Message(
					new MessageHeader("protocolo", 0, false, 0, 0),
					new MessageBody(
							null,
							null,
							new ReplyHeader("", 0, 0),
							new ReplyBody(reply.getResponse())));
			
			this.outMarshalledMessage = marshaller.marshall(this.outUnmarshalledMessage);
			break;
			
		case "sub":
			Float _sub_p1 = (Float) this.inUnmarshalledMessage.getBody()
			.getRequestBody().getParameter(0);
			Float _sub_p2 = (Float) this.inUnmarshalledMessage.getBody()
					.getRequestBody().getParameter(1);
			reply.setResponse(new Calculator().sub(_sub_p1, _sub_p2));

			this.outUnmarshalledMessage
			= new Message(
					new MessageHeader("protocolo", 0, false, 0, 0),
					new MessageBody(
							null,
							null,
							new ReplyHeader("", 0, 0),
							new ReplyBody(reply.getResponse())));
			
			this.outMarshalledMessage = marshaller.marshall(this.outUnmarshalledMessage);
			break;
		case "mul":
			Float _mul_p1 = (Float) this.inUnmarshalledMessage.getBody()
			.getRequestBody().getParameter(0);
			Float _mul_p2 = (Float) this.inUnmarshalledMessage.getBody()
					.getRequestBody().getParameter(1);
			reply.setResponse(new Calculator().add(_mul_p1, _mul_p2));

			this.outUnmarshalledMessage
			= new Message(
					new MessageHeader("protocolo", 0, false, 0, 0),
					new MessageBody(
							null,
							null,
							new ReplyHeader("", 0, 0),
							new ReplyBody(reply.getResponse())));
			
			this.outMarshalledMessage = marshaller.marshall(this.outUnmarshalledMessage);
			break;
		case "div":
			Float _div_p1 = (Float) this.inUnmarshalledMessage.getBody()
			.getRequestBody().getParameter(0);
			Float _div_p2 = (Float) this.inUnmarshalledMessage.getBody()
					.getRequestBody().getParameter(1);
			reply.setResponse(new Calculator().add(_div_p1, _div_p2));

			this.outUnmarshalledMessage
			= new Message(
					new MessageHeader("protocolo", 0, false, 0, 0),
					new MessageBody(
							null,
							null,
							new ReplyHeader("", 0, 0),
							new ReplyBody(reply.getResponse())));
			
			this.outMarshalledMessage = marshaller.marshall(this.outUnmarshalledMessage);
			break;
		default:
			break;
		}
		
		return this.outMarshalledMessage;
	}
}
