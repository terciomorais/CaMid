package br.ufpe.cin.in1118.distribution.server;

import br.ufpe.cin.in1118.distribution.marshaling.Marshaller;
import br.ufpe.cin.in1118.distribution.protocol.Message;
import br.ufpe.cin.in1118.distribution.protocol.MessageBody;
import br.ufpe.cin.in1118.distribution.protocol.MessageHeader;
import br.ufpe.cin.in1118.distribution.protocol.ReplyBody;
import br.ufpe.cin.in1118.distribution.protocol.ReplyDescriptor;
import br.ufpe.cin.in1118.distribution.protocol.ReplyHeader;
import br.ufpe.cin.in1118.distribution.stub.NamingStub;
import br.ufpe.cin.in1118.distribution.stub.Stub;
import br.ufpe.cin.in1118.services.commons.naming.Naming;

public class NamingInvoker {
	private byte[]			incomingMessage			= null;
	private Message			inUnmarshalledMessage	= null;
	private Message 		outUnmarshalledMessage	= null;
	private byte[]			outMarshalledMessage	= null;
	private ReplyDescriptor	reply 					= new ReplyDescriptor();
	private Naming			naming					= Naming.getInstance();
	
	public NamingInvoker(){}
	
	public NamingInvoker(byte[] receivedMessage){
		this.incomingMessage = receivedMessage;
	}
	
	public void setIncomingMessage(byte[] incomingMessage){
		this.incomingMessage = incomingMessage;
	}
		
	public byte[] invoke() throws Throwable {
		Marshaller marshaller = new Marshaller();
		this.inUnmarshalledMessage = marshaller.unmarshall(this.incomingMessage);
		
		switch (this.inUnmarshalledMessage.getBody().getRequestHeader().getOperation()) {
		case "bind":
			String serviceName = (String) this.inUnmarshalledMessage.getBody().getRequestBody().getParameter(0);
			Stub stub = (Stub) this.inUnmarshalledMessage.getBody().getRequestBody().getParameter(1);
			naming.bind(serviceName, stub);
			
			this.outUnmarshalledMessage
			= new Message(
				new MessageHeader("protocolo", 0, false, 0, 0),
				new MessageBody(
						null,
						null,
						new ReplyHeader("", 0, 0),
						new ReplyBody(null)));
		
			this.outMarshalledMessage
				= marshaller.marshall(this.outUnmarshalledMessage);
			break;

		case "lookup":
			String _lookup_param1 = (String) this.inUnmarshalledMessage.getBody().getRequestBody().getParameter(0);
			reply.setResponse(naming.lookup(_lookup_param1));

			this.outUnmarshalledMessage = new Message(
				new MessageHeader("protocolo", 0, false, 0, 0),
				new MessageBody(
						null,
						null,
						new ReplyHeader("", 0, 0),
						new ReplyBody(reply.getResponse())));
		
			this.outMarshalledMessage
				= marshaller.marshall(this.outUnmarshalledMessage);
			break;
			
		case "list":
			reply.setResponse(naming.list());
			this.outUnmarshalledMessage
			= new Message(
				new MessageHeader("protocolo", 0, false, 0, 0),
				new MessageBody(
						null,
						null,
						new ReplyHeader("", 0, 0),
						new ReplyBody(reply.getResponse())));
			this.outMarshalledMessage
				= marshaller.marshall(this.outUnmarshalledMessage);
			break;
		case "unbind":
			break;
		default:
			break;
		}
		
		return this.outMarshalledMessage;
	}

}
