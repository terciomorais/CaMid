package br.ufpe.cin.in1118.distribution.stub;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import br.ufpe.cin.in1118.distribution.client.Requestor;
import br.ufpe.cin.in1118.distribution.protocol.InvocationDescriptor;
import br.ufpe.cin.in1118.distribution.protocol.ReplyDescriptor;
import br.ufpe.cin.in1118.services.commons.naming.INaming;

public class NamingStub extends Stub implements INaming {

	private static final long serialVersionUID = 1L;

	public NamingStub(String host, int port) {
		this.setHost(host);
		this.setPort(port);
	}

	@Override
	public void bind(String serviceName, Stub stub)
			throws UnknownHostException, IOException, Throwable {
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		//ReplyDescriptor			reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Naming");
		invocation.addParameter(serviceName);
		invocation.addParameter(stub);
		invocation.setHasReturn(false);
		
		requestor.invoke(invocation);
		
		return;	
	}

	@Override
	public Stub lookup(String serviceName) throws UnknownHostException,
			IOException, Throwable {
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		Stub					reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Naming");
		invocation.addParameter(serviceName);
		
		reply = (Stub)requestor.invoke(invocation).getResponse();
		return reply;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<String> list() throws UnknownHostException, IOException,
			Throwable {
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		ArrayList<String>		reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Naming");
		
		reply = (ArrayList<String>)requestor.invoke(invocation).getResponse();
		return reply;
	}

}
