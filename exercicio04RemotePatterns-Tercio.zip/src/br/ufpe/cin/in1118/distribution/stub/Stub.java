package br.ufpe.cin.in1118.distribution.stub;

import java.io.Serializable;

public abstract class Stub implements Serializable{

	protected String	host;
	protected int 		port;
	protected int 		objectId;
	
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public int getObjectId() {
		return objectId;
	}
	public void setObjectId(int objectId) {
		this.objectId = objectId;
	}
	
}
