package br.ufpe.cin.in1118.distribution.stub;

import java.io.IOException;
import java.net.UnknownHostException;

import br.ufpe.cin.in1118.distribution.client.Requestor;
import br.ufpe.cin.in1118.distribution.protocol.InvocationDescriptor;
import br.ufpe.cin.in1118.distribution.protocol.ReplyDescriptor;

public class CalculatorStub extends Stub implements ICalculator{
	private static final long serialVersionUID = 1L;

	@Override
	public float add(float x, float y){
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		ReplyDescriptor			reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Calculator");
		invocation.addParameter(x);
		invocation.addParameter(y);
		
		try {
			reply = requestor.invoke(invocation);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		return (float) reply.getResponse();
	}

	@Override
	public float sub(float x, float y)  {
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		ReplyDescriptor			reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Calculator");
		invocation.addParameter(x);
		invocation.addParameter(y);
		
		try {
			reply = requestor.invoke(invocation);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		return (float) reply.getResponse();
	}

	@Override
	public float mul(float x, float y){
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		ReplyDescriptor			reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Calculator");
		invocation.addParameter(x);
		invocation.addParameter(y);
		
		try {
			reply = requestor.invoke(invocation);
		} catch (UnknownHostException e) {
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		return (float) reply.getResponse();
	}

	@Override
	public float div(float x, float y) {
		InvocationDescriptor	invocation	= new InvocationDescriptor();
		Requestor 				requestor	= new Requestor();
		ReplyDescriptor			reply		= null;
		
		class Local {};
		
		invocation.setHostIP(this.getHost());
		invocation.setPort(this.getPort());
		invocation.setObjectID(this.getObjectId());
		
		invocation.setMethodName(Local.class.getEnclosingMethod().getName());
		invocation.setRemoteObjName("Calculator");
		invocation.addParameter(x);
		invocation.addParameter(y);
		
		try {
			reply = requestor.invoke(invocation);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		return (float) reply.getResponse();
	}
}
