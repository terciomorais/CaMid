package br.ufpe.cin.in1118.distribution.client;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;

import br.ufpe.cin.in1118.distribution.marshaling.Marshaller;
import br.ufpe.cin.in1118.distribution.protocol.InvocationDescriptor;
import br.ufpe.cin.in1118.distribution.protocol.Message;
import br.ufpe.cin.in1118.distribution.protocol.MessageBody;
import br.ufpe.cin.in1118.distribution.protocol.MessageHeader;
import br.ufpe.cin.in1118.distribution.protocol.RequestBody;
import br.ufpe.cin.in1118.distribution.protocol.RequestHeader;
import br.ufpe.cin.in1118.distribution.protocol.ReplyDescriptor;
import br.ufpe.cin.in1118.infrastructure.client.ClientRequestHandler;
import br.ufpe.cin.in1118.infrastructure.client.ClientSender;

public class Requestor {

	public ReplyDescriptor invoke (InvocationDescriptor inv) throws UnknownHostException, IOException, Throwable{

		ClientRequestHandler	clientRequestHandler	= ClientRequestHandler.getInstance();
		Message 				messageToBeMarshelled 	= null;		
		byte []					messageMarshelled		= null;
		byte []					replyMarshalled			= null;
		Message					replyUnmarshalled		= null;
		ReplyDescriptor			reply					= null;

		//map
		boolean hasReturn = inv.isHasReturn();
		RequestHeader	requestHeader	= new RequestHeader(
											"", 0, hasReturn, 0, inv.getMethodName());
		RequestBody		requestBody 	= new RequestBody(inv.getParameters());
		MessageHeader	messageHeader	= new MessageHeader("contexto", 0, false, 0, 0);
		MessageBody		messageBody 	= new MessageBody(requestHeader, requestBody, null, null);
		
		messageToBeMarshelled 	= new Message(messageHeader, messageBody);

		//marshall
		Marshaller marshaller = new Marshaller();
		messageMarshelled = marshaller.marshall(messageToBeMarshelled);

		//send and receive to server
		ClientSender clientSender
			= new ClientSender(inv.getHostIP(), inv.getPort(), messageMarshelled);
		
		replyMarshalled = clientRequestHandler.submit(clientSender);

		//unmarshall reply
		if(inv.isHasReturn()){
			replyUnmarshalled = marshaller.unmarshall(replyMarshalled);

			reply = new ReplyDescriptor();
			reply.setResponse((Serializable)replyUnmarshalled.getBody().getReplyBody().getOperationResult());
		}
		return reply;
	}
}
