package br.ufpe.cin.in1118.distribution.skeleton;

public class Calculator {
	
	public Float add(float a, float b){
		return a + b;
	}
	
	public Float sub(float a, float b){
		return a - b;
	}
	
	public Float mul(float a, float b){
		return a * b;
	}
	
	public Float div(float a, float b){
		if (b != 0)
			return a / b;
		else
			return null;
	}
}
