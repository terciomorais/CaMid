package br.ufpe.cin.in1118.services.commons.naming;

import br.ufpe.cin.in1118.distribution.stub.Stub;

public class NamingRecord {
	private String	serviceName;
	private Stub	stub;
	
	public NamingRecord(String serviceName, Stub stub){
		this.setServiceName(serviceName);
		this.setStub(stub);
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public Stub getStub() {
		return stub;
	}
	public void setStub(Stub stub) {
		this.stub = stub;
	}
}
