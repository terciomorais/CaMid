package br.ufpe.cin.in1118.services.commons.naming;

import java.util.ArrayList;

public class NamingRepository {
	
	private ArrayList<NamingRecord> repository = new ArrayList<NamingRecord>();
	
	public NamingRepository(){}
	
	public void addRecord(NamingRecord namingRecord){
		this.repository.add(namingRecord);
	}
	
	public void removeRecord(String serviceName){
		for(NamingRecord nr : this.repository){
			if (nr.getServiceName().equals(serviceName))
				this.repository.remove(nr);
		}
	}
	
	public NamingRecord find(String serviceName){
		NamingRecord target = null;
		for(NamingRecord nr : this.repository){
			if (nr.getServiceName().equals(serviceName))
				target = nr;
		}
		return target;
	}
	
	public void clearRecord(){
		this.repository.clear();
	}

}
