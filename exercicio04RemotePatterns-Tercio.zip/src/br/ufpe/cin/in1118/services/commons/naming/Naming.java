package br.ufpe.cin.in1118.services.commons.naming;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import br.ufpe.cin.in1118.distribution.stub.Stub;

public class Naming implements INaming {

	private static Naming		INSTANCE;
	private NamingRepository	repository		= new NamingRepository();
	private ArrayList<String>	serviceNames	= new ArrayList<String>();
	
	public static Naming getInstance(){
		if (INSTANCE == null)
			INSTANCE = new Naming();
		return INSTANCE;
	}
	
	private void addRecord (NamingRecord namingRecord){
		this.repository.addRecord(namingRecord);
	}
	
	@Override
	public synchronized void bind(String serviceName, Stub stub)
			throws UnknownHostException, IOException, Throwable {
		this.addRecord(new NamingRecord(serviceName, stub));
		this.serviceNames.add(serviceName);
	}
	
	public synchronized void unbind(String serviceName){
		this.repository.removeRecord(serviceName);
		this.serviceNames.remove(serviceName);
	}

	@Override
	public synchronized Stub lookup(String serviceName) throws UnknownHostException,
			IOException, Throwable {
		NamingRecord nr = this.repository.find(serviceName);
		
		if (nr != null)
			return nr.getStub();
		else
			return null;	
	}

	@Override
	public synchronized ArrayList<String> list() throws UnknownHostException, IOException,
			Throwable {
		return null;
	}
}
