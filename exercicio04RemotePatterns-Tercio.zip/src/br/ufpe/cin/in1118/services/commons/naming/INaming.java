package br.ufpe.cin.in1118.services.commons.naming;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import br.ufpe.cin.in1118.distribution.stub.Stub;

public interface INaming {
	public void bind(String serviceName, Stub stub) throws UnknownHostException, IOException, Throwable;
	
	public Stub lookup(String serviceName) throws UnknownHostException, IOException, Throwable;
	
	public ArrayList<String> list() throws UnknownHostException, IOException, Throwable;
}
