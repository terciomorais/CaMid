package br.ufpe.cin.in1118.infrastructure.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ClientRequestHandler {

	private static ClientRequestHandler	INSTANCE;
	private ExecutorService 			executor	= Executors.newCachedThreadPool();

	//private String 						host 		= "localhost";
	//private int							port 		= 1313;

	public static synchronized ClientRequestHandler getInstance() {
		if(INSTANCE == null) {
			INSTANCE = new ClientRequestHandler();
		}
		return INSTANCE;
	}


	public void setConnection(String host, int port){
	//	this.host	= host;
	//	this.port	= port;
	}

	public byte[] submit(ClientSender clientSender) {
		byte[] response = null;
//		ClientSender clientSender = new ClientSender(this.host, this.port, messageMarshelled);
		
		Future<byte[]> futureMsg = executor.submit(clientSender);
		

		try {
			response = futureMsg.get();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		return response;
	}

	public void close(){
		executor.shutdown();
		INSTANCE = null;
	}
}
