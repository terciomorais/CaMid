package br.ufpe.cin.in1118.infrastructure.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Callable;

public class ClientSender implements Callable<byte[]> {
	private DataOutputStream	os				= null;
	private DataInputStream		is				= null;
	private Socket				conn			= null;
	
	private String				host			= "localhost";
	private int					port			= 1313;
	
	private byte[]				receivedMessage	= null;
	private byte[]				mesageToSend	= null;
	private int 				receivedMessageSize;
	private int 				mesageToSendSize;
	
	public ClientSender(String host, int port, byte[] marshelledMessage){
		this.host 			= host;
		this.port			= port;
		this.mesageToSend	= marshelledMessage;
	}

	@Override
	public byte[] call() throws Exception {
		try {
			this.conn	= new Socket(this.host, this.port);
			this.is		= new DataInputStream(this.conn.getInputStream());
			this.os		= new DataOutputStream(this.conn.getOutputStream());
			
			this.mesageToSendSize = this.mesageToSend.length;
			this.os.writeInt(this.mesageToSendSize);
			this.os.write(this.mesageToSend);
			this.os.flush();
			
			this.receivedMessageSize = this.is.readInt();
			this.receivedMessage = new byte[this.receivedMessageSize];
			this.is.read(this.receivedMessage, 0, this.receivedMessageSize);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			if(this.is != null)
				this.is.close();
			if(this.os != null)
				this.os.close();
			if(!this.conn.isClosed())
				this.conn.close();
		}
		return this.receivedMessage;
	}
}
