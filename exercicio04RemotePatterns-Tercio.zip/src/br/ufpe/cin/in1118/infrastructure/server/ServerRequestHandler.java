package br.ufpe.cin.in1118.infrastructure.server;

import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServerRequestHandler {

	private static	ServerRequestHandler INSTANCE;
	protected ExecutorService	executor	= Executors.newCachedThreadPool();
	
	public static synchronized ServerRequestHandler getInstance(){
		if (INSTANCE == null)
			INSTANCE = new ServerRequestHandler();
		return INSTANCE;
	}
	
	public void receive(Socket conn){
		this.executor.execute(new Receiver(conn));
	}
}
