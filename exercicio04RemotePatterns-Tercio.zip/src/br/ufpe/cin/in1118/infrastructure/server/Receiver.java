package br.ufpe.cin.in1118.infrastructure.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import br.ufpe.cin.in1118.distribution.server.CalculatorInvoker;

public class Receiver implements Runnable{

	private Socket				conn = null;
	private int					replyMessageSize;
	private int					receiveMessageSize;
	private DataOutputStream	outToClient;
	private DataInputStream		inFromClient;
	
	public Receiver(Socket conn){
		this.conn = conn;
	}

	@Override
	public void run() {
		byte[]				receivedMessage	= null;
		CalculatorInvoker	invoker;
		byte[]				replyMessage = null;

		try {
			this.outToClient 		= new DataOutputStream(this.conn.getOutputStream());
			this.inFromClient		= new DataInputStream(this.conn.getInputStream());
			this.receiveMessageSize	= this.inFromClient.readInt();
			receivedMessage 		= new byte [this.receiveMessageSize];
			this.inFromClient.read(receivedMessage, 0, this.receiveMessageSize);
			invoker = new CalculatorInvoker(receivedMessage);
			replyMessage = invoker.invoke();
			this.replyMessageSize = replyMessage.length;
			
			this.outToClient.writeInt(this.replyMessageSize);
			this.outToClient.write(replyMessage);
			this.outToClient.flush();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			try {
				this.conn.close();
				this.inFromClient.close();
				this.outToClient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
	}
}
